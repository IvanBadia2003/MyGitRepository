
package patron_adapter;


public interface Conectable {
    public boolean isEncendida();
    public void encender();
    public void apagar();
}
