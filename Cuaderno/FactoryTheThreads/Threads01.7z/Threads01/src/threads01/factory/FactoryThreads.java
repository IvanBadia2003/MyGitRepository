
package threads01.factory;


public class FactoryThreads {
    private static final String COMANDANTE = "COMANDANTE";
    private static final String CENTURION = "CENTURION";
    private static final String SOLDADO = "SOLDADO";
    
    public static RomaSoldier getInstance(){
        return "";
    }
    
}
