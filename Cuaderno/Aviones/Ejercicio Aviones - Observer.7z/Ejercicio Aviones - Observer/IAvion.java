public interface IAvion {
    public void girarDerecha();
    public void girarIzquierda();
}